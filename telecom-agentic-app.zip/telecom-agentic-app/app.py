# app.py
from fastapi import FastAPI
import numpy as np
import pandas as pd
from xgboost import XGBClassifier
import uvicorn
from crewai import Agent, Task

# Load model
try:
    model = XGBClassifier()
    model.load_model("models/churn_model.json")  # Use XGBoost's native method
    print("✅ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    raise SystemExit(1)

# Data preprocessing function
def preprocess_input(customer_data):
    df = pd.DataFrame([customer_data])
    df = df.drop(columns=["customerID"], errors='ignore')
    # Ensure consistent feature order and fill missing columns
    return df.reindex(columns=model.feature_names_in_, fill_value=0)

# Churn Predictor Agent
class ChurnPredictorAgent:
    def __init__(self):
        self.name = "Churn Predictor"
    
    def predict_churn(self, customer_data):
        try:
            df = preprocess_input(customer_data)
            probability = model.predict_proba(df)[0][1]
            # Convert numpy.float32 to Python float
            probability = float(probability)  # .item() is redundant for float32
            print(f"📊 {self.name} - Churn probability for {customer_data['customerID']}: {probability:.2f}")
            return {"churn_probability": probability}
        except Exception as e:
            print(f"❌ {self.name} - Error: {e}")
            return {"churn_probability": 0.0}

# Retention Strategist Agent
class RetentionStrategistAgent:
    def __init__(self):
        self.name = "Retention Strategist"
    
    def generate_offer(self, customer, probability):
        base_offer = "Free 10GB data for 3 months"
        if customer["Contract_Month-to-month"]:
            base_offer += " + 15% plan discount"
        elif probability > 0.8:
            base_offer += " + Free device upgrade"
        print(f"🎯 {self.name} - Offer generated: {base_offer}")
        return {"offer": base_offer}

# Notification Agent
class NotificationAgent:
    def __init__(self):
        self.name = "Notification Manager"
    
    def send_notification(self, customer_id, offer):
        print(f"📩 {self.name} - Sent offer to {customer_id}: {offer}")
        return {"status": "sent"}

# Example customers
customers = [
    {
        "customerID": "C101",
        "tenure": 1,
        "MonthlyCharges": 95,
        "Contract_Month-to-month": 1,
        "Complaints": 5
    },
    {
        "customerID": "C102",
        "tenure": 24,
        "MonthlyCharges": 70,
        "Contract_Month-to-month": 0,
        "Complaints": 1
    }
]

# Initialize agents
churn_agent = ChurnPredictorAgent()
strategist_agent = RetentionStrategistAgent()
notify_agent = NotificationAgent()

# FastAPI setup
app = FastAPI(title="Telecom Churn Prediction API")

@app.get("/")
def read_root():
    results = []
    print("\n🚀 Starting churn prediction workflow...\n")
    for customer in customers:
        print(f"\n👤 Processing customer: {customer['customerID']}")
        
        # Predict churn
        churn_result = churn_agent.predict_churn(customer)
        
        # Generate offer if churn risk > 40%
        if churn_result["churn_probability"] > 0.4:
            print(f"⚠️ Churn risk detected for {customer['customerID']} ({churn_result['churn_probability']:.2f})")
            offer = strategist_agent.generate_offer(customer, churn_result["churn_probability"])
            notify_agent.send_notification(customer["customerID"], offer["offer"])
            results.append({
                "customer_id": customer["customerID"],
                "churn_probability": churn_result["churn_probability"],
                "offer": offer["offer"]
            })
        else:
            print(f"✅ {customer['customerID']} is at low churn risk")
            results.append({
                "customer_id": customer["customerID"],
                "churn_probability": churn_result["churn_probability"],
                "status": "low risk"
            })
    return {"results": results}

# Run the app
# if __name__ == "__main__":
#     uvicorn.run(app, host="127.0.0.1", port=8000)