# train_model.py
import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
import os

# Generate consistent mock data
num_samples = 100
data = {
    "customerID": [f"C{i}" for i in range(num_samples)],
    "tenure": np.random.choice([1, 2, 3, 6, 12, 24, 36], size=num_samples),
    "MonthlyCharges": np.round(np.random.uniform(20, 100, size=num_samples), 2),
    "Contract_Month-to-month": np.random.choice([0, 1], size=num_samples, p=[0.7, 0.3]),
    "Complaints": np.random.randint(0, 8, size=num_samples),
    "Churn_Yes": np.random.choice([0, 1], size=num_samples, p=[0.8, 0.2])
}

df = pd.DataFrame(data)

# Ensure models directory exists
os.makedirs("models", exist_ok=True)

# Data preprocessing
def preprocess_data(df):
    return df.drop(columns=["customerID"])

df = preprocess_data(df)

# Split features and target
X = df.drop(columns=["Churn_Yes"])
y = df["Churn_Yes"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = XGBClassifier(eval_metric='logloss')
model.fit(X_train, y_train)

# Save model using XGBoost's native method
model.save_model("models/churn_model.json")
print("✅ Model trained and saved to models/churn_model.json")